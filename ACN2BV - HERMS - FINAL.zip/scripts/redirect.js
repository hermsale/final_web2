// redireccionamos del index al home en el perfil alejandro
document.getElementById('alejandro-profile').addEventListener('click', function() {
    window.location.href = 'home.php';
});

document.getElementById('profile-nuevo').addEventListener('click', function() {
    window.location.href = 'registro.php';
});